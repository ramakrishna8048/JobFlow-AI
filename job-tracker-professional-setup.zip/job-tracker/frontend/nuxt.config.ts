export default defineNuxtConfig({
  typescript: {
    strict: true
  },
  app: {
    head: {
      title: 'Job Tracker'
    }
  }
})
