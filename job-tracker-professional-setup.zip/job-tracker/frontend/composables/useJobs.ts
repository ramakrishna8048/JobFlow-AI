// Placeholder composable for job tracking logic
export function getJobs() {
  return []
}
