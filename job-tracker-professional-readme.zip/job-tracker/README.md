# 📊 Job Tracker – Full Stack Resume Project

This is a **job application tracking dashboard** built with a modern full-stack architecture using **Vue/Nuxt 3, TypeScript, Python AWS Lambdas, and Terraform** — all designed to run on **free-tier services only**.

---

## 🧩 Project Overview

The Job Tracker helps job seekers organize and visualize their application progress in one place. It features:

- ✅ Daily count of job applications
- 📅 Upcoming interview & exam reminders
- 🧠 Daily Python/DevOps practice task suggestions
- 📬 Gmail integration to auto-extract job applications (via Gmail API)
- 📊 Dashboard UI with filtering and analytics
- ☁️ Deployed with AWS free-tier services using Terraform

---

## 🛠️ Tech Stack

| Layer         | Tech                       |
|--------------|----------------------------|
| Frontend      | Nuxt 3 (Vue + TypeScript) |
| Styling       | TailwindCSS               |
| Backend API   | Python AWS Lambda         |
| Email Parser  | Gmail API via OAuth       |
| Infrastructure| Terraform (IaC)           |
| Deployment    | GitHub Actions + S3       |
| CI/CD         | GitHub Actions            |

---

## 📂 Project Structure

```
job-tracker/
├── frontend/         # Nuxt 3 SPA
├── backend/          # Python Lambdas for Gmail & Job Data
├── terraform/        # Infrastructure as Code (S3, Lambda, API Gateway)
└── .github/          # CI/CD workflow with GitHub Actions
```

---

## 🧪 Features Planned (Modular Design)

- [x] Professional Nuxt project setup
- [x] Gmail parser Lambda stub
- [x] Daily learning task JSON pool
- [x] Terraform modules for AWS resources
- [ ] Gmail OAuth flow
- [ ] Persistent job database (DynamoDB)
- [ ] Email reminders for follow-up
- [ ] Resume analysis with AI (future scope)

---

## 📄 License

This project is released under the [MIT License](LICENSE).

---

## 🤝 Let's Connect

This project is part of my technical portfolio. I'm open to feedback, collaboration, or hiring opportunities.

Feel free to [connect with me on LinkedIn](https://www.linkedin.com/in/ramakrishna-reddy-1a3a59169/)
