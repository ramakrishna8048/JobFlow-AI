# Placeholder: Gmail parser function
def handler(event, context):
    return {"statusCode": 200, "body": "Gmail parser placeholder"}
