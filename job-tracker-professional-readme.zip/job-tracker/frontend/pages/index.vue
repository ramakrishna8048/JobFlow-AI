<template>
  <div class="p-6">
    <h1 class="text-2xl font-bold mb-4">📊 Job Tracker Dashboard</h1>
    <p>This is a placeholder for the main dashboard UI.</p>
  </div>
</template>

<script setup lang="ts">
// Placeholder script
</script>
